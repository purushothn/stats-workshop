Statistical Analysis Workshop: Getting Started with R

A one-hour hands-on workshop for high school students. It teaches R basics, descriptive statistics, the two-sample t-test and one-way ANOVA with Tukey letters. Students work in Posit Cloud, so nothing is installed on the Chromebook.

Folders

index.html is the workshop page that GitHub Pages serves.
data holds example_data.xlsx, exercise_data.xlsx and CSV copies of each sheet.
scripts holds workshop.R, exercise.R and exercise_solutions.R.

To use the scripts directly, upload them and the Excel files to a Posit Cloud RStudio project and run them one line at a time.

The data are simulated for teaching.
