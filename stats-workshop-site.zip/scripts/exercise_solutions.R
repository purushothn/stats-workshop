# EXERCISE SOLUTIONS: Music, sleep, and school performance

library(readxl)
library(multcompView)

# Task 1
music_data <- read_excel("exercise_data.xlsx", sheet = "ttest")
sleep_data <- read_excel("exercise_data.xlsx", sheet = "anova")
head(music_data)
head(sleep_data)

# Task 2
mean(music_data$reaction_ms)
median(music_data$reaction_ms)
sd(music_data$reaction_ms)

music_data$music <- factor(music_data$music, levels = c("Silence", "Music"))
tapply(music_data$reaction_ms, music_data$music, mean)
tapply(music_data$reaction_ms, music_data$music, sd)

boxplot(reaction_ms ~ music, data = music_data,
        xlab = "Condition", ylab = "Reaction time (ms)",
        main = "Reaction time by condition",
        col = c("lightblue", "orange"))

# Task 3
music_test <- t.test(reaction_ms ~ music, data = music_data)
music_test
# Students reacted more slowly with music than in silence (p is about 0.009,
# which is below 0.05), so the difference is significant.

# Task 4
sleep_data$sleep_group <- factor(sleep_data$sleep_group,
                                 levels = c("Under 6 hours", "6 to 8 hours", "Over 8 hours"))

boxplot(test_score ~ sleep_group, data = sleep_data,
        xlab = "Sleep", ylab = "Test score",
        main = "Test score by sleep group",
        col = c("grey70", "lightgreen", "gold"))

sleep_model <- aov(test_score ~ sleep_group, data = sleep_data)
summary(sleep_model)

sleep_tukey <- TukeyHSD(sleep_model)
sleep_tukey

sleep_cld <- multcompLetters4(sleep_model, sleep_tukey)$sleep_group$Letters
sleep_cld

sleep_means <- tapply(sleep_data$test_score, sleep_data$sleep_group, mean)
bp <- barplot(sleep_means, ylim = c(0, 100),
              xlab = "Sleep", ylab = "Mean test score",
              col = "lightgreen")
text(bp, sleep_means + 4, labels = sleep_cld[names(sleep_means)], cex = 1.5)
# Over 8 hours and 6 to 8 hours share the letter "a", so they are not different.
# Under 6 hours has a different letter, so it scored lower than both.

# Bonus
hist(sleep_data$test_score, main = "Test scores", xlab = "Score", col = "lightblue")
