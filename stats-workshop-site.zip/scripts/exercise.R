# EXERCISE: Music, sleep, and school performance
# Data file: exercise_data.xlsx
#   sheet "ttest": music (Silence or Music), reaction_ms (reaction time in milliseconds)
#   sheet "anova": sleep_group (3 groups), test_score (0 to 100)
# Lower reaction time means a faster response.

library(readxl)
library(multcompView)

# Task 1. Read both sheets and look at the first rows
music_data <- read_excel("exercise_data.xlsx", sheet = "ttest")
sleep_data <- read_excel("exercise_data.xlsx", sheet = "anova")
head(music_data)
head(sleep_data)

# Task 2. Descriptive statistics
# a) Find the mean, median and sd of reaction_ms for all students.
# b) Find the mean and sd of reaction_ms for each music group (use tapply).
# c) Make a boxplot of reaction_ms by music.


# Task 3. t-test
# Does music change reaction time? Run t.test and write your conclusion
# in a comment. Include the p-value.


# Task 4. One-way ANOVA
# Does the amount of sleep change test scores?
# a) Make the sleep_group column a factor with levels in this order:
#    "Under 6 hours", "6 to 8 hours", "Over 8 hours"
# b) Make a boxplot of test_score by sleep_group.
# c) Fit the model with aov() and print summary().
# d) Run TukeyHSD() and find the compact letters with multcompLetters4().
# e) Make a bar plot of the group means with the letters on top.


# Bonus. Make a histogram of test_score. Is the shape roughly symmetric?
