# STATISTICAL ANALYSIS WORKSHOP: Getting started with R
# Run one line at a time: click on a line and press Ctrl + Enter.

# ============================================================
# PART 0. Set up packages
# ============================================================

# Run these lines once at the start.
# The install line can take about a minute. Skip it if your instructor says
# the packages are already installed in your project.
install.packages(c("readxl", "multcompView"))

# Load the packages every time you start a new session
library(readxl)
library(multcompView)

# ============================================================
# PART 1. R basics
# ============================================================

# R works like a very powerful calculator
5 + 3
20 / 4
2 ^ 3
sqrt(81)

# Store a value in an object using the arrow <-
age <- 16
age

# A vector holds several values. c() means "combine".
heights <- c(150, 162, 158, 171, 165)
heights

# Functions do something with your data
mean(heights)
median(heights)
length(heights)
max(heights)

# You can do math on a whole vector at once
heights / 100

# Text goes inside quotes
my_name <- "Sam"
my_name

# Ask R for help on any function
?mean

# ============================================================
# PART 2. Load the Excel data
# ============================================================

# See which files are in your project
list.files()

# Read the two sheets of the example Excel file
plants_t <- read_excel("example_data.xlsx", sheet = "ttest")
plants_a <- read_excel("example_data.xlsx", sheet = "anova")

# Look at the data
head(plants_t)
str(plants_t)
nrow(plants_t)
View(plants_t)

# ============================================================
# PART 3. Descriptive statistics
# ============================================================

# Pick one column of a data table with the $ sign
plant_heights <- plants_t$height_cm
plant_heights

# Descriptive statistics for all 30 plants
mean(plant_heights)
median(plant_heights)
sd(plant_heights)
min(plant_heights)
max(plant_heights)
summary(plant_heights)

# A histogram shows the shape of the data
hist(plant_heights, main = "Plant heights", xlab = "Height (cm)", col = "lightblue")

# Put Water first, then describe each treatment group
plants_t$treatment <- factor(plants_t$treatment, levels = c("Water", "Fertilizer"))

tapply(plants_t$height_cm, plants_t$treatment, mean)
tapply(plants_t$height_cm, plants_t$treatment, sd)
tapply(plants_t$height_cm, plants_t$treatment, length)

# A boxplot compares groups
boxplot(height_cm ~ treatment, data = plants_t,
        xlab = "Treatment", ylab = "Height (cm)",
        main = "Plant height by treatment",
        col = c("lightblue", "lightgreen"))

# ============================================================
# PART 4. Two-sample t-test
# ============================================================

# Question: do plants given fertilizer grow taller than plants given only water?
# Null hypothesis: the two group means are equal.

result <- t.test(height_cm ~ treatment, data = plants_t)
result

# Pull out the pieces you want to report
result$p.value
result$estimate

# Decision rule: if p is smaller than 0.05, the group means are
# significantly different. Write your conclusion in a sentence:
# "Plants given fertilizer were taller than plants given water (p < 0.05)."

# ============================================================
# PART 5. One-way ANOVA with Tukey letters
# ============================================================

# Question: does the amount of light change plant height?
# There are three groups, so we use a one-way ANOVA.

plants_a$light <- factor(plants_a$light, levels = c("Shade", "Partial", "Full"))

boxplot(height_cm ~ light, data = plants_a,
        xlab = "Light", ylab = "Height (cm)",
        main = "Plant height by light level",
        col = c("grey70", "lightgreen", "gold"))

# Fit the model and read the ANOVA table
model <- aov(height_cm ~ light, data = plants_a)
summary(model)

# ANOVA only tells us that at least one group is different.
# Tukey's test shows which pairs of groups are different.
tukey <- TukeyHSD(model)
tukey

# Compact letters: groups that share a letter are NOT significantly different.
# The letter "a" goes to the group with the highest mean.
cld <- multcompLetters4(model, tukey)$light$Letters
cld

# Summary table with means and letters
group_means <- tapply(plants_a$height_cm, plants_a$light, mean)
summary_table <- data.frame(
  light = names(group_means),
  mean_height = round(as.numeric(group_means), 1),
  group = cld[names(group_means)]
)
rownames(summary_table) <- NULL
summary_table

# Bar plot of the means with the letters on top
bp <- barplot(group_means, ylim = c(0, max(group_means) + 5),
              xlab = "Light", ylab = "Mean height (cm)",
              col = "lightgreen")
text(bp, group_means + 1, labels = cld[names(group_means)], cex = 1.5)

